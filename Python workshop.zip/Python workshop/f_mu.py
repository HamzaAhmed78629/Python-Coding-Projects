# f_mu.py
# Logistic map function

def f_mu(mu, x):
    return mu * x * (1 - x)
