# The Turtle Module
# cantor3.py
#

from turtle import *
def cantor3(x , y , length):
    if length >= 5: # Exit program if length < 5
        speed(0)    # Set fastest speed
        penup()     # Raise the turtle
        pensize(3)  # Line Thickness
        pencolor("black")
        setpos(x , y)
        pendown()
        fd(length)  # Foward
        y -=30      #y - y - 30
        cantor3(x , y , length / 5)
        cantor3(x + 2 * length / 5 , y , length / 5)
        cantor3(x + 4 * length / 5 , y , length / 5)
        penup()
        setpos(x , y + 30)
