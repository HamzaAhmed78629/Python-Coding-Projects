Python 3.7.8 (tags/v3.7.8:4b47a5b6ba, Jun 28 2020, 08:53:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 2**8
256
>>> import,math #Import the math libary
SyntaxError: invalid syntax
>>> import math #Import the math library
>>> math.sqrt(9)
3.0
>>> from math import * #Import ALL functions
>>> sin(0.5)
0.479425538604203
>>> asin(0.4794)
0.499970899146915
>>> asin #Inverse Sin
<built-in function asin>
>>> degrees(pi)
180.0
>>> radians(90)
1.5707963267948966
>>> log(2)
0.6931471805599453
>>> log10(10)
1.0
>>> exp(2)
7.38905609893065
>>> e**2
7.3890560989306495
>>> fmod (13 , 6)
1.0
>>> fmod (13 , 6) #Modulo arithmatic
1.0
>>> 13 % 6
1
>>> gcd(123 , 321)
3
>>> lcm(3 , 4 , 5) #Lowest Common Multiple
Traceback (most recent call last):
  File "<pyshell#18>", line 1, in <module>
    lcm(3 , 4 , 5) #Lowest Common Multiple
NameError: name 'lcm' is not defined
>>> 1 / 3 + 1 / 4
0.5833333333333333
>>> lcm
Traceback (most recent call last):
  File "<pyshell#20>", line 1, in <module>
    lcm
NameError: name 'lcm' is not defined
>>> form fractions inport Fraction
SyntaxError: invalid syntax
>>> from fractions import Fraction
>>> Fraction(1 , 3) + Fraction (1 , 4)
Fraction(7, 12)
>>> Fraction(7, 12) - 0.5833333333333333
1.1102230246251565e-16
>>> pi
3.141592653589793
>>> round(_ , 5)
3.14159
>>> factorial(52) # Number of permuations of a pack of playing card
80658175170943878571660636856403766975289505440883277824000000000000
>>> factorial(78)
11324281178206297831457521158732046228731749579488251990048962825668835325234200766245086213177344000000000000000000
>>> ceil(2.5)
3
>>> ceil(-2.5)
-2
>>> ceil(5.5)
6
>>> ciel(-7.5)
Traceback (most recent call last):
  File "<pyshell#32>", line 1, in <module>
    ciel(-7.5)
NameError: name 'ciel' is not defined
>>> ceil(-7.5)
-7
>>> floor(2.5)
2
>>> floor(-2.5)
-3
>>> trunc(2.5)
2
>>> trunc(-2.5)
-2
>>> clear
Traceback (most recent call last):
  File "<pyshell#38>", line 1, in <module>
    clear
NameError: name 'clear' is not defined
>>> #intro to lists
>>> a = [1 , 2 , 3 , 4 , 5] # Our First list
>>> type(a)
<class 'list'>
>>> a[0] # zero based indexing
1
>>> a[1]
2
>>> a[-1]
5
>>> a[-2]
4
>>> a[-3]
3
>>> a[-4]
2
>>> a[1]
2
>>> a[3]
4
>>> len(a)
5
>>> min(a)
1
>>> max{a)
SyntaxError: invalid syntax
>>> max(1)
Traceback (most recent call last):
  File "<pyshell#53>", line 1, in <module>
    max(1)
TypeError: 'int' object is not iterable
>>> max(a)
5
>>> 5 in a
True
>>> 3 in a
True
>>> 5 in a
True
>>> 6 in a
False
>>> 22 in a
False
>>> a
[1, 2, 3, 4, 5]
>>> 2 * a
[1, 2, 3, 4, 5, 1, 2, 3, 4, 5]
>>> len(a
    len(a)
    
SyntaxError: invalid syntax
>>> len(_)
10
>>> a.append(6)
>>> a
[1, 2, 3, 4, 5, 6]
>>> a.remove(6)
>>> a
[1, 2, 3, 4, 5]
>>> b = 2 * a
>>> b
[1, 2, 3, 4, 5, 1, 2, 3, 4, 5]
>>> a
[1, 2, 3, 4, 5]
>>> c = 3 * a
>>> c
[1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]
>>> 
>>> b
[1, 2, 3, 4, 5, 1, 2, 3, 4, 5]
>>> a
[1, 2, 3, 4, 5]
>>> print(a)
[1, 2, 3, 4, 5]
>>> # Slicing.
>>> a[1 : 3] # From a[1] up to but not including a[3]
[2, 3]
>>> a
[1, 2, 3, 4, 5]
>>> a[2 : 4]
[3, 4]
>>> a[1:]
[2, 3, 4, 5]
>>> a[0:]
[1, 2, 3, 4, 5]
>>> a[:-2]
[1, 2, 3]
>>> list(range(5))
[0, 1, 2, 3, 4]
>>> list(range(4 , 9))
[4, 5, 6, 7, 8]
>>> list(range(2 , 10 , 2))
[2, 4, 6, 8]
>>> A = [[1 , 2] , [3 , 4]] #A 2X2 list
>>> A[0][1]
2
>>> A[1][0]
3
>>> A[3][4]
Traceback (most recent call last):
  File "<pyshell#91>", line 1, in <module>
    A[3][4]
IndexError: list index out of range
>>> A[1] [1]
4
>>> names = ["haz", "Jimmy", "Kevin"]
>>> names.index("haz")
0
>>> names.pop(2)
'Kevin'
>>> names
['haz', 'Jimmy']
>>> 