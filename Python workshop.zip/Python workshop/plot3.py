# plot3.py
"""
Created on Tue May 28 14:26:49 2024
Output in an oscilloscope.
@author: hamza
"""

import numpy as np
import matplotlib.pyplot as plt
t = np.arange(0 , 2 , 0.01) # Vector of t values.
c = 1 * np.cos(2 * np.pi * t)
s = 1 * np.sin(2 * np.pi * t)
plt.plot(t , s , "r--" , t , c , "b-.")
plt.xlabel("Time (s)")
plt.ylabel("Voltage (mV)")
plt.title("Voltage Time Plot")
plt.grid(True)
plt.show()
