# Numerical Methods ODEs and PDEs
"""
Created on Thu May 30 12:01:05 2024

@author: hamza
"""
# Euler's Method
import numpy as np
import matplotlib.pyplot as plt
f = lambda x , y: 1 - y # The ODE
h , y0 = 0.01 , 2        # Step size as y(0)
x = np.arange(0 , 1 + h, h) #Numerical grid
y , y[0] = np.zeros(len(x)) , y0
for n in range(0 , len(x) - 1):
    y[n + 1] = y[n] + h * f(x[n] , y[n]) # Eulers formula
plt.rcParams["font.size"] = "16"
plt.figure()
plt.plot(x , y , "r--" , label = "Numerical Solution")
plt.plot(x , np.exp(x) + 1 , "b" , label = "Analytical solution")
plt.xlabel("x")
plt.ylabel("y")
plt.grid()
plt.legend(loc = "upper right")
plt.show()