# save as fractal_tree_color.py
# Bifurcating Tree.
from turtle import *
setheading(90)      # Turtle points up. Tree grwos verstically.
penup()
setpos(0 , -250)    # Bottom of the page
pendown()           # put the pen back down
def fractal_tree_color(length , level):
    pensize(length / 10)    # as tree grwosn branches gets thinner and thinner
    if length < 20:
        pencolor("green")
    else:
        pencolor("brown")
    speed(0)
    if level > 0:
        fd(length)          # foward that length
        rt(30)              # right turn 30 degrees
        fractal_tree_color(length * 0.7 , level -1) #Done the right branch
        lt(90)      # left turn 90 degrees
        fractal_tree_color(length * 0.5 , level -1) #Done the left branch
        rt(60)      # Turtle points straight up
        penup()
        bk(length)
        pendown()
