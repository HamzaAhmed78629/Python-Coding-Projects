# plot1.py.
"""
A simple parabola

"""
import numpy as np
import matplotlib.pyplot as plt
x = np.linspace(-2 , 2 , 100) #A Vector
y = x**2
plt.xlabel("x")
plt.ylabel("y")
plt.plot(x , y)
plt.savefig("Parabola.png" , dpi = 400)
plt.show()