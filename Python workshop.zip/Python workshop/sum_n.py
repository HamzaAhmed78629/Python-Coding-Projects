# sum_n.py
"""
Sum of the first n natural numbers.
"""

def sum_n(n):
    sum, i = 0 , 1
    while i<= n:
        sum += i # sum = sum + i
        i += 1   #i = i + 1
    print("The sum is: " , sum)
