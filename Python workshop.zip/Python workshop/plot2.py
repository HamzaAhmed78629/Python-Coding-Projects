# plot2.py
"""
Created on Tue May 28 14:26:49 2024
A parametric plot
@author: hamza
"""

import numpy as np
import matplotlib.pyplot as plt
t = np.linspace(0 , np.pi , 1000)
x = 0.7 * np.sin(t + 1) * np.sin(5 * t)
y = 0.7 * np.cos(t + 1) * np.sin(5 * t)
plt.xlabel("x(t)")
plt.ylabel("y(t)")
plt.title("Parametric Plot")
plt.plot(x , y , color = "cyan")
plt.show()