#Run the module (F5).

def sqr(x):
    return x**2
